## This MD file shows what is coming in a next update:
- {This item has been added: Password Manager. All other commands are not here YET!}
- More turtle commands {Delayed}
- {Not Confirmed} improvement of layout, No longer launching from a command line {Delayed}
- {Not Confirmed} Execute bash commands - output in the terminal {Will not have all commands} {Delayed
