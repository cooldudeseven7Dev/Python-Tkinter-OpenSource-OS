if you are having problems, make sure you are using main.py AND are using it as a runnable python file  
If you still have problems (such as No such module as `ast` or something like that then remove the following line {line 3 of the file} :  
`from ast import main`
