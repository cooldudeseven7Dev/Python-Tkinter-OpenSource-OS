Password manager is now availible! It is not in the command list. Use PasswordManager command to get the password manager prerelease!

Collaborators: cooldudeseven7Dev (Owner/Creator), cds7YT (co-owner, fixer, alt for cooldudeseven7Dev, not that active)
# OpenSource-OperatingSystem
100% python!
## Rules
DO NOT CLAIM THIS AS YOUR OWN.
This is an Open Source OS.
You May:
- Redistribute WITH CREDIT
- Remix WITH CREDIT
- Buissness Use WITH CREDIT
- Personal Use

You may not:
- Claim/Redistribute as your own
- Not give credit
 
 ##Must read before use
 
IMPORTANT MESSAGE TO ALL USERS:
- DO NOT USE THIS AS A RECOVERY OS. THIS NEEDS A OS ALREADY INSTALLED AND PYTHON ON YOUR PC TO USE. 

Tips
- If you'd like to quit the os, Use the quitOS command OR close the console window (do not close turtle graphics or the tkinter window)

## How to use
- read the text above
- Choose a version you'd like to use {Latest Suggested}
- Install python or use somthing that can run python
- Run main.py

### 😊 Thanks for using the project! We are always looking for colabarators
