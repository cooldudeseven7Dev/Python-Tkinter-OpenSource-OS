# OpenSource-OperatingSystem
## Rules
DO NOT CLAIM THIS AS YOUR OWN.
This is an Open Source OS.
You May:
- Redistribute WITH CREDIT
- Remix WITH CREDIT
- Buissness Use WITH CREDIT
- Personal Use

You may not:
- Claim/Redistribute as your own
- Not give credit
- Use as a personal ALL THE TIME operating system {This is too crappy and small}

## How to use
Choose a version you'd like to use {Latest Suggested}
Install python or use somthing that can run python
Run main.py

### 😊 Thanks for using the project! We are always looking for colabarators
